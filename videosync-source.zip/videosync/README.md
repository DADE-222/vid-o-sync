# VideoSync – VST3 pour FL Studio

Affiche une vidéo dans FL Studio, parfaitement calée sur la timeline (lecture, pause, déplacement du curseur).

## Installation (utilisateur)
Lancez `VideoSync-Setup.exe` (droits administrateur). Puis dans FL Studio :
*Options > Manage plugins > Find installed plugins*, et chargez **VideoSync** sur une piste du **mixeur**.

## Utilisation
1. Glissez une vidéo dans la fenêtre (ou « Charger une vidéo »).
2. La première fois, la vidéo est préparée (quelques secondes à quelques minutes selon sa durée) ; ensuite c'est instantané.
3. Lancez la lecture dans FL Studio : l'image affichée est toujours celle de l'instant exact de la timeline.

### Synchronisation
- **Parfaite** (60 Hz, recommandée) / **Équilibrée** (30 Hz) / **Économe** (15 Hz).
- **Décalage image** (±2000 ms, boutons ±1 image) : compense la latence de votre carte son.
- **Mode calibration** : flash blanc à chaque seconde de la timeline. Placez un clap sur une seconde pile
  (à 120 BPM, 1 s = 2 temps), écoutez, et réglez le décalage jusqu'à ce que son et flash coïncident.
  Le réglage est sauvegardé dans le projet.

## Fonctionnement
Pas de lecteur vidéo qui avance seul (il dériverait) : la vidéo est convertie une fois en un fichier de cache
où chaque image est un JPEG indépendant (`%LOCALAPPDATA%\VideoSync\cache`), et le plugin affiche l'image
correspondant à la position de la timeline. Le son de la vidéo n'est pas lu (il vient de FL Studio).

## Compilation (développeurs, Linux → Windows)
```
cmake -S . -B build -G Ninja -DCMAKE_TOOLCHAIN_FILE=cmake/mingw-toolchain.cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build
```
Puis copier `VideoSync.vst3` et `ffmpeg.exe` dans `installer/stage/` et lancer `makensis installer/VideoSync.nsi`.
JUCE 7.0.12 (AGPLv3 / licence commerciale). ffmpeg 7.1.1 : build LGPL minimal (décodeurs vidéo courants + encodeur MJPEG), voir `LICENSE-ffmpeg.txt`.
