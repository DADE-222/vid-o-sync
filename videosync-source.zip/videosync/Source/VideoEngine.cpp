#include "VideoEngine.h"

namespace
{
    constexpr int maxCachedFrames = 40;
    constexpr int proxyWidth = 960;

}

VideoEngine::VideoEngine() : juce::Thread ("VideoSync conversion") {}

VideoEngine::~VideoEngine()
{
    ++generation;
    stopThread (15000);
}

juce::String VideoEngine::getMessage() const
{
    const juce::ScopedLock sl (lock);
    return message;
}

void VideoEngine::setMessage (const juce::String& m)
{
    const juce::ScopedLock sl (lock);
    message = m;
}

juce::String VideoEngine::getVideoName() const
{
    return inputFile.getFileName();
}

juce::File VideoEngine::findFfmpeg()
{
    // ffmpeg.exe est installé à côté du plugin (dans le dossier .vst3)
    const auto dll = juce::File::getSpecialLocation (juce::File::currentExecutableFile);
    const auto local = dll.getSiblingFile ("ffmpeg.exe");
    if (local.existsAsFile())
        return local;
    return {};
}

juce::File VideoEngine::cacheFileFor (const juce::File& input) const
{
    juce::File root;
    const auto local = juce::SystemStats::getEnvironmentVariable ("LOCALAPPDATA", {});
    if (local.isNotEmpty())
        root = juce::File (local);
    else
        root = juce::File::getSpecialLocation (juce::File::tempDirectory);

    const auto key = input.getFullPathName() + "|" + juce::String (input.getSize())
                     + "|" + juce::String (input.getLastModificationTime().toMilliseconds())
                     + "|v1|" + juce::String (proxyWidth);

    return root.getChildFile ("VideoSync").getChildFile ("cache")
               .getChildFile ("video_" + juce::String::toHexString (key.hashCode64()) + ".avi");
}

void VideoEngine::load (const juce::File& video)
{
    if (! juce::MessageManager::getInstance()->isThisTheMessageThread())
    {
        juce::WeakReference<VideoEngine> weak (this);
        juce::MessageManager::callAsync ([weak, video]
        {
            if (weak != nullptr)
                weak->load (video);
        });
        return;
    }

    ++generation;
    stopThread (15000);   // interrompt une éventuelle conversion en cours

    mapped.reset();
    index = {};
    cache.clear();
    cacheOrder.clear();
    setMessage ({});

    inputFile = video;

    if (! video.existsAsFile())
    {
        fail (juce::String::fromUTF8 ("Fichier introuvable : ") + video.getFullPathName());
        return;
    }

    const auto avi = cacheFileFor (video);

    if (avi.existsAsFile())
    {
        openProxy (avi);
        return;
    }

    state = State::Converting;
    progress = -1.0;
    sendChangeMessage();
    startThread();
}

void VideoEngine::fail (const juce::String& msg)
{
    setMessage (msg);
    state = State::Failed;
    progress = -1.0;
    sendChangeMessage();
}

void VideoEngine::openProxy (const juce::File& avi)
{
    auto mm = std::make_unique<juce::MemoryMappedFile> (avi, juce::MemoryMappedFile::readOnly);

    if (mm->getData() == nullptr)
    {
        fail (juce::String::fromUTF8 ("Impossible d'ouvrir le fichier de cache vidéo."));
        return;
    }

    AviIndex idx;
    if (! idx.parse (static_cast<const uint8_t*> (mm->getData()), (uint64_t) mm->getSize()))
    {
        mm.reset();
        avi.deleteFile();   // cache corrompu : sera recréé au prochain chargement
        fail (juce::String::fromUTF8 ("Le fichier de cache vidéo est invalide. Rechargez la vidéo."));
        return;
    }

    mapped = std::move (mm);
    index = std::move (idx);
    state = State::Ready;
    progress = 1.0;
    sendChangeMessage();
}

juce::Image VideoEngine::getFrame (int frameIndex)
{
    if (state.load() != State::Ready || frameIndex < 0 || frameIndex >= (int) index.frames.size())
        return {};

    if (auto it = cache.find (frameIndex); it != cache.end())
        return it->second;

    const auto& f = index.frames[(size_t) frameIndex];
    const auto* bytes = static_cast<const uint8_t*> (mapped->getData());
    auto img = juce::ImageFileFormat::loadFrom (bytes + f.offset, (size_t) f.size);

    if (img.isValid())
    {
        cache[frameIndex] = img;
        cacheOrder.push_back (frameIndex);

        while ((int) cacheOrder.size() > maxCachedFrames)
        {
            cache.erase (cacheOrder.front());
            cacheOrder.pop_front();
        }
    }

    return img;
}

// Thread de conversion : lance ffmpeg pour créer le proxy "une image JPEG par image vidéo"
void VideoEngine::run()
{
    const int myGeneration = generation.load();
    const auto input = inputFile;
    const auto avi = cacheFileFor (input);
    const auto tmp = avi.withFileExtension (".tmp");

    auto finish = [this, myGeneration, avi] (bool ok, const juce::String& msg)
    {
        juce::WeakReference<VideoEngine> weak (this);
        juce::MessageManager::callAsync ([weak, myGeneration, ok, avi, msg]
        {
            if (weak == nullptr || weak->generation.load() != myGeneration)
                return;

            if (ok) weak->openProxy (avi);
            else    weak->fail (msg);
        });
    };

    avi.getParentDirectory().createDirectory();
    tmp.deleteFile();

    const auto ffmpeg = findFfmpeg();
    if (! ffmpeg.existsAsFile())
    {
        finish (false, juce::String::fromUTF8 ("ffmpeg.exe est introuvable (réinstallez VideoSync)."));
        return;
    }

    juce::StringArray args;
    args.add (ffmpeg.getFullPathName());
    args.addArray ({ "-y", "-hide_banner", "-nostats", "-progress", "pipe:1", "-i" });
    args.add (input.getFullPathName());
    args.addArray ({ "-an", "-sn", "-dn",
                     "-vf", "scale='min(" + juce::String (proxyWidth) + ",iw)':-2",
                     "-c:v", "mjpeg", "-q:v", "4", "-pix_fmt", "yuvj420p",
                     "-f", "avi" });
    args.add (tmp.getFullPathName());

    juce::ChildProcess process;
    if (! process.start (args, juce::ChildProcess::wantStdOut | juce::ChildProcess::wantStdErr))
    {
        finish (false, juce::String::fromUTF8 ("Impossible de lancer ffmpeg."));
        return;
    }

    double duration = 0.0;
    juce::String pending, errors;
    char buffer[4096];

    auto handleLine = [&] (const juce::String& line)
    {
        if (line.startsWith ("out_time_us=") || line.startsWith ("out_time_ms="))
        {
            const double seconds = line.fromFirstOccurrenceOf ("=", false, false).getDoubleValue() / 1.0e6;
            if (duration > 0.0)
                progress = juce::jlimit (0.0, 0.99, seconds / duration);
        }
        else if (line.contains ("Duration:") && duration <= 0.0)
        {
            auto t = line.fromFirstOccurrenceOf ("Duration:", false, false).trim()
                         .upToFirstOccurrenceOf (",", false, false).trim();
            auto parts = juce::StringArray::fromTokens (t, ":", "");
            if (parts.size() == 3)
                duration = parts[0].getDoubleValue() * 3600.0 + parts[1].getDoubleValue() * 60.0
                           + parts[2].getDoubleValue();
        }
        else if (! line.containsChar ('=') || line.contains ("rror"))
        {
            errors = (errors + line + "\n").getLastCharacters (500);
        }
    };

    while (! threadShouldExit())
    {
        const int n = process.readProcessOutput (buffer, (int) sizeof (buffer) - 1);

        if (n > 0)
        {
            pending += juce::String::fromUTF8 (buffer, n);

            for (int nl = pending.indexOfChar ('\n'); nl >= 0; nl = pending.indexOfChar ('\n'))
            {
                handleLine (pending.substring (0, nl).trim());
                pending = pending.substring (nl + 1);
            }
        }
        else if (! process.isRunning())
        {
            break;
        }
        else
        {
            juce::Thread::sleep (20);
        }
    }

    if (threadShouldExit())
    {
        process.kill();
        tmp.deleteFile();
        return;   // chargement annulé ou remplacé
    }

    process.waitForProcessToFinish (5000);
    const auto exitCode = process.getExitCode();

    if (exitCode == 0 && tmp.existsAsFile() && tmp.getSize() > 0 && tmp.moveFileTo (avi))
    {
        finish (true, {});
    }
    else
    {
        tmp.deleteFile();
        finish (false, juce::String::fromUTF8 ("La conversion a échoué. ") + errors.trim());
    }
}
