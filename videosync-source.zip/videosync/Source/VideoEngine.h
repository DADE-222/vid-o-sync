#pragma once

#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_graphics/juce_graphics.h>
#include "AviIndex.h"
#include <atomic>
#include <deque>
#include <map>
#include <memory>

// Moteur vidéo "image par image".
//
// Au chargement, la vidéo est convertie (une seule fois, puis mise en cache) en un fichier
// proxy où CHAQUE image est une image JPEG indépendante. On peut ainsi afficher n'importe quelle
// image instantanément et de façon exacte, sans lecteur vidéo qui dérive : l'image affichée est
// calculée directement à partir de la position de la timeline de FL Studio.
class VideoEngine : private juce::Thread,
                    public juce::ChangeBroadcaster
{
public:
    enum class State { Idle, Converting, Ready, Failed };

    VideoEngine();
    ~VideoEngine() override;

    void load (const juce::File& video);   // utilisable depuis n'importe quel thread

    State getState() const noexcept     { return state.load(); }
    double getProgress() const noexcept { return progress.load(); }   // 0..1, ou -1 si inconnu
    juce::String getMessage() const;
    juce::String getVideoName() const;

    double getFps() const noexcept      { return index.fps; }
    int getFrameCount() const noexcept  { return (int) index.frames.size(); }
    double getDuration() const noexcept { return index.fps > 0.0 ? (double) index.frames.size() / index.fps : 0.0; }

    juce::Image getFrame (int frameIndex);   // thread des messages uniquement

private:
    void run() override;
    void openProxy (const juce::File& avi);
    void fail (const juce::String& msg);
    void setMessage (const juce::String& m);

    static juce::File findFfmpeg();
    juce::File cacheFileFor (const juce::File& input) const;

    std::atomic<State> state { State::Idle };
    std::atomic<double> progress { -1.0 };
    std::atomic<int> generation { 0 };

    juce::File inputFile;
    mutable juce::CriticalSection lock;
    juce::String message;

    std::unique_ptr<juce::MemoryMappedFile> mapped;
    AviIndex index;

    std::map<int, juce::Image> cache;
    std::deque<int> cacheOrder;

    JUCE_DECLARE_WEAK_REFERENCEABLE (VideoEngine)
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VideoEngine)
};
