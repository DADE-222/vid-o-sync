#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "VideoEngine.h"
#include <atomic>

// Effet audio "transparent" : il ne modifie pas le son. Il lit la position de lecture de
// FL Studio (timeline) et la fournit à l'éditeur, qui affiche l'image vidéo correspondante.
class VideoSyncProcessor : public juce::AudioProcessor
{
public:
    // Modes de synchronisation (fréquence de rafraîchissement de l'image)
    enum SyncMode { Perfect = 0, Balanced = 1, Light = 2 };

    VideoSyncProcessor();
    ~VideoSyncProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "VideoSync"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    // --- Transport hôte (écrit par le thread audio, lu par l'éditeur) ---
    std::atomic<double> hostTimeSeconds { 0.0 };
    std::atomic<double> hostStampMs     { 0.0 };   // horloge système au moment de la mesure
    std::atomic<bool>   hostPlaying     { false };
    std::atomic<bool>   hostTimeValid   { false };

    // --- Réglages (sauvegardés avec le projet FL Studio) ---
    std::atomic<float> offsetMs { 0.0f };          // décalage image (+ = image plus tôt)
    std::atomic<int>   syncMode { Perfect };

    VideoEngine engine;

    juce::String getVideoPath() const;
    void loadVideo (const juce::File& file);

private:
    double sampleRate = 44100.0;

    mutable juce::CriticalSection pathLock;
    juce::String videoPath;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VideoSyncProcessor)
};
