#pragma once

#include "PluginProcessor.h"
#include <juce_gui_basics/juce_gui_basics.h>

// Zone d'affichage : montre l'image vidéo qui correspond exactement à l'instant demandé.
class VideoView : public juce::Component
{
public:
    explicit VideoView (VideoEngine& e) : engine (e) {}

    void reset();
    void setTime (bool timeValid, double seconds, bool calibration);
    void setHint (const juce::String& text) { hint = text; repaint(); }
    void paint (juce::Graphics&) override;

private:
    VideoEngine& engine;
    juce::Image current;
    juce::String hint;
    int frameIndex = -2;
    bool valid = false, flash = false, calib = false;
    double timeSec = 0.0;
};

class VideoSyncEditor : public juce::AudioProcessorEditor,
                        public juce::FileDragAndDropTarget,
                        private juce::ChangeListener,
                        private juce::Timer
{
public:
    explicit VideoSyncEditor (VideoSyncProcessor&);
    ~VideoSyncEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag (const juce::StringArray& files) override;
    void filesDropped (const juce::StringArray& files, int x, int y) override;

private:
    void timerCallback() override;
    void changeListenerCallback (juce::ChangeBroadcaster*) override;
    void chooseVideo();
    void updateStatus();
    void applyMode();
    void nudge (int frames);

    VideoSyncProcessor& proc;

    VideoView view;
    juce::TextButton loadButton;
    juce::Label statusLabel, modeLabel, offsetLabel;
    juce::ComboBox modeBox;
    juce::Slider offsetSlider;
    juce::TextButton minusFrame, plusFrame, zeroButton;
    juce::ToggleButton calibrationToggle;
    double progressValue = -1.0;
    juce::ProgressBar progressBar { progressValue };

    std::unique_ptr<juce::FileChooser> chooser;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VideoSyncEditor)
};
