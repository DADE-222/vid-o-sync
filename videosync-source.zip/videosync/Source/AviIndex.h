#pragma once

// Lecteur minimal de fichier AVI (MJPEG) : retrouve la position de chaque image JPEG.
// Code volontairement indépendant de JUCE (testable seul).

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <vector>

struct AviIndex
{
    struct Frame { uint64_t offset; uint32_t size; };

    std::vector<Frame> frames;
    double fps = 0.0;
    int width = 0, height = 0;

    bool parse (const uint8_t* data, uint64_t size)
    {
        frames.clear();
        fps = 0.0;
        width = height = 0;
        haveVideo = wantStrf = false;
        base = data;
        total = size;

        if (size < 12 || std::memcmp (data, "RIFF", 4) != 0 || std::memcmp (data + 8, "AVI ", 4) != 0)
            return false;

        // Un fichier peut contenir plusieurs segments RIFF (AVI puis AVIX pour les gros fichiers)
        uint64_t pos = 0;
        while (pos + 12 <= total && std::memcmp (base + pos, "RIFF", 4) == 0)
        {
            const uint64_t sz = rd32 (base + pos + 4);
            uint64_t end = pos + 8 + sz;
            if (end > total) end = total;
            parseChunks (pos + 12, end);
            pos = end + (end & 1);
        }

        return fps > 0.0 && ! frames.empty();
    }

private:
    const uint8_t* base = nullptr;
    uint64_t total = 0;
    bool haveVideo = false, wantStrf = false;

    static uint32_t rd32 (const uint8_t* p)
    {
        return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
    }

    void parseChunks (uint64_t begin, uint64_t end)
    {
        uint64_t p = begin;
        while (p + 8 <= end)
        {
            const uint8_t* h = base + p;
            uint64_t sz = rd32 (h + 4);
            const uint64_t body = p + 8;
            if (body + sz > end) sz = end - body;
            const uint64_t next = body + sz + (sz & 1);

            if (std::memcmp (h, "LIST", 4) == 0 && sz >= 4)
            {
                const uint8_t* t = base + body;
                if (std::memcmp (t, "hdrl", 4) == 0 || std::memcmp (t, "strl", 4) == 0)
                    parseChunks (body + 4, body + sz);
                else if (std::memcmp (t, "movi", 4) == 0)
                    parseMovi (body + 4, body + sz);
            }
            else if (std::memcmp (h, "strh", 4) == 0 && sz >= 28 && ! haveVideo)
            {
                if (std::memcmp (base + body, "vids", 4) == 0)
                {
                    const uint32_t scale = rd32 (base + body + 20);
                    const uint32_t rate  = rd32 (base + body + 24);
                    if (scale != 0) fps = (double) rate / (double) scale;
                    wantStrf = true;
                }
            }
            else if (std::memcmp (h, "strf", 4) == 0 && wantStrf && sz >= 12)
            {
                width  = (int) rd32 (base + body + 4);
                height = std::abs ((int) (int32_t) rd32 (base + body + 8));
                wantStrf = false;
                haveVideo = true;
            }

            p = next;
        }
    }

    void parseMovi (uint64_t begin, uint64_t end)
    {
        uint64_t p = begin;
        while (p + 8 <= end)
        {
            const uint8_t* h = base + p;
            uint64_t sz = rd32 (h + 4);
            const uint64_t body = p + 8;
            if (body + sz > end) sz = end - body;
            const uint64_t next = body + sz + (sz & 1);

            if (h[0] == '0' && h[1] == '0' && h[2] == 'd' && (h[3] == 'c' || h[3] == 'b'))
                frames.push_back ({ body, (uint32_t) sz });
            else if (std::memcmp (h, "LIST", 4) == 0 && sz >= 4 && std::memcmp (base + body, "rec ", 4) == 0)
                parseMovi (body + 4, body + sz);

            p = next;
        }
    }
};
