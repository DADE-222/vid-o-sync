#include "PluginProcessor.h"
#include "PluginEditor.h"

VideoSyncProcessor::VideoSyncProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
}

void VideoSyncProcessor::prepareToPlay (double newSampleRate, int)
{
    sampleRate = newSampleRate > 0.0 ? newSampleRate : 44100.0;
}

bool VideoSyncProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::stereo() || out == juce::AudioChannelSet::mono())
           && out == layouts.getMainInputChannelSet();
}

void VideoSyncProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    // Lecture de la position de la timeline de FL Studio
    bool valid = false;

    if (auto* ph = getPlayHead())
    {
        if (auto pos = ph->getPosition())
        {
            hostPlaying.store (pos->getIsPlaying());

            if (auto t = pos->getTimeInSeconds())
            {
                hostTimeSeconds.store (*t);
                valid = true;
            }
            else if (auto s = pos->getTimeInSamples())
            {
                hostTimeSeconds.store ((double) *s / sampleRate);
                valid = true;
            }

            if (valid)
                hostStampMs.store (juce::Time::getMillisecondCounterHiRes());
        }
    }

    hostTimeValid.store (valid);

    // Le son passe sans modification (buffer traité "sur place").
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, buffer.getNumSamples());
}

juce::AudioProcessorEditor* VideoSyncProcessor::createEditor()
{
    return new VideoSyncEditor (*this);
}

juce::String VideoSyncProcessor::getVideoPath() const
{
    const juce::ScopedLock sl (pathLock);
    return videoPath;
}

void VideoSyncProcessor::loadVideo (const juce::File& file)
{
    {
        const juce::ScopedLock sl (pathLock);
        videoPath = file.getFullPathName();
    }
    engine.load (file);
}

void VideoSyncProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    juce::XmlElement xml ("VideoSyncState");
    xml.setAttribute ("path",   getVideoPath());
    xml.setAttribute ("offset", (double) offsetMs.load());
    xml.setAttribute ("mode",   syncMode.load());
    copyXmlToBinary (xml, destData);
}

void VideoSyncProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
    {
        if (xml->hasTagName ("VideoSyncState"))
        {
            offsetMs.store ((float) xml->getDoubleAttribute ("offset", 0.0));
            syncMode.store (juce::jlimit (0, 2, xml->getIntAttribute ("mode", Perfect)));

            const auto path = xml->getStringAttribute ("path");
            if (path.isNotEmpty())
                loadVideo (juce::File (path));
        }
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VideoSyncProcessor();
}
