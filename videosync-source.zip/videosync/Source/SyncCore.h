#pragma once
// Logique de synchronisation pure (sans JUCE) : testable sur n'importe quelle plateforme.

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <regex>
#include <sstream>
#include <string>

namespace vsync
{
//==============================================================================
inline double wallNowSeconds() noexcept
{
    using namespace std::chrono;
    return duration<double> (steady_clock::now().time_since_epoch()).count();
}

//==============================================================================
// Photo de l'état du transport de l'hôte (FL Studio), prise par le thread audio.
struct HostSnapshot
{
    double hostTime = 0.0;   // position de la timeline (secondes)
    double wall     = 0.0;   // horloge locale au moment de la mesure
    double ppq      = 0.0;   // position en noires
    double bpm      = 120.0;
    bool   playing  = false;
    bool   valid    = false;
    uint64_t serial = 0;     // nombre de publications (rempli par la lecture)
};

// Canal sans verrou : 1 écrivain (thread audio) -> 1 lecteur (interface). "Seqlock".
class SnapshotChannel
{
public:
    void publish (const HostSnapshot& s) noexcept
    {
        const uint64_t q = seq.load (std::memory_order_relaxed);
        seq.store (q + 1, std::memory_order_relaxed);
        std::atomic_thread_fence (std::memory_order_release);
        hostTime.store (s.hostTime, std::memory_order_relaxed);
        wall.store (s.wall, std::memory_order_relaxed);
        ppq.store (s.ppq, std::memory_order_relaxed);
        bpm.store (s.bpm, std::memory_order_relaxed);
        flags.store ((s.playing ? 1u : 0u) | (s.valid ? 2u : 0u), std::memory_order_relaxed);
        seq.store (q + 2, std::memory_order_release);
    }

    bool read (HostSnapshot& out) const noexcept
    {
        for (int attempt = 0; attempt < 200; ++attempt)
        {
            const uint64_t s1 = seq.load (std::memory_order_acquire);
            if (s1 & 1u)
                continue;
            if (s1 == 0)
                return false;   // rien n'a encore été publié

            out.hostTime = hostTime.load (std::memory_order_relaxed);
            out.wall     = wall.load (std::memory_order_relaxed);
            out.ppq      = ppq.load (std::memory_order_relaxed);
            out.bpm      = bpm.load (std::memory_order_relaxed);
            const uint32_t f = flags.load (std::memory_order_relaxed);
            out.playing = (f & 1u) != 0;
            out.valid   = (f & 2u) != 0;

            std::atomic_thread_fence (std::memory_order_acquire);
            if (seq.load (std::memory_order_relaxed) == s1)
            {
                out.serial = s1 / 2;
                return true;
            }
        }
        return false;
    }

private:
    std::atomic<uint64_t> seq { 0 };
    std::atomic<double> hostTime { 0.0 }, wall { 0.0 }, ppq { 0.0 }, bpm { 120.0 };
    std::atomic<uint32_t> flags { 0 };
};

//==============================================================================
// Cadence d'images exacte (29.97 = 30000/1001, etc.) pour éviter toute dérive à long terme.
struct Fps
{
    int num = 25;
    int den = 1;
    double value() const noexcept { return den > 0 ? (double) num / (double) den : 25.0; }
    std::string str() const { return std::to_string (num) + "/" + std::to_string (den); }
    bool operator== (const Fps& o) const noexcept { return num == o.num && den == o.den; }
};

inline Fps canonicalFps (double approx)
{
    if (! (approx > 0.5))   return { 25, 1 };
    if (approx > 60.5)      return { 60, 1 };

    static const Fps ntsc[] = { { 24000, 1001 }, { 30000, 1001 }, { 48000, 1001 }, { 60000, 1001 } };
    for (const auto& f : ntsc)
        if (std::abs (approx - f.value()) < 0.02)
            return f;

    const double r = std::round (approx);
    if (std::abs (approx - r) < 0.02)
        return { (int) r, 1 };

    return { (int) std::lround (approx * 1000.0), 1000 };
}

// -1 : avant le début ; totalFrames : après la fin ; sinon index de l'image.
inline int64_t frameForTime (double t, double fps, int64_t totalFrames) noexcept
{
    if (t < 0.0)
        return -1;
    const int64_t n = (int64_t) std::floor (t * fps + 1e-6);
    return n >= totalFrames ? totalFrames : n;
}

inline std::string formatTimecode (double t, double fps)
{
    if (t < 0.0) t = 0.0;
    const int64_t secs  = (int64_t) std::floor (t + 1e-9);
    const int frame     = (int) std::floor ((t - (double) secs) * fps + 1e-6);
    char buf[48];
    std::snprintf (buf, sizeof (buf), "%02d:%02d:%02d:%02d",
                   (int) (secs / 3600), (int) ((secs / 60) % 60), (int) (secs % 60), frame);
    return buf;
}

// Flash de calibration : vrai pendant les premières millisecondes de chaque temps.
inline bool beatFlash (double ppq, double bpm, double flashSeconds = 0.07) noexcept
{
    if (bpm < 1.0) return false;
    const double phase = ppq - std::floor (ppq);          // 0..1 dans le temps courant
    return phase * 60.0 / bpm < flashSeconds;
}

//==============================================================================
struct SyncParams
{
    double latencySec = 0.0;           // retard de la carte son : l'image est retardée d'autant
    double fineSec = 0.0;              // décalage fin
    double maxExtrapolationSec = 0.25; // on n'extrapole jamais plus loin que ça sans nouvelle info
};

struct TimeEstimate
{
    bool   valid = false;
    bool   playing = false;
    double videoTime = 0.0;   // instant de la vidéo à afficher MAINTENANT
    double hostTime = 0.0;
    double ppqAtVideo = 0.0;  // position en noires correspondant à l'image affichée (calibration)
    double bpm = 120.0;
};

// L'hôte ne nous donne la position qu'à chaque bloc audio (par ex. toutes les 10 à 40 ms).
// L'estimateur la lisse avec l'horloge locale pour que l'image avance sans à-coups,
// tout en restant verrouillée sur la position réelle de FL Studio (aucune dérive possible :
// la position est recalée en permanence).
class SyncEstimator
{
public:
    void feed (const HostSnapshot& s) noexcept
    {
        if (s.serial == lastSerial && haveSnapSerial)
            return;

        lastSerial = s.serial;
        haveSnapSerial = true;
        snap = s;
        haveSnap = s.valid;

        if (! s.valid)
        {
            wasPlaying = false;
            haveOffset = false;
            return;
        }

        if (s.playing)
        {
            const double sample = s.hostTime - s.wall;
            if (! wasPlaying || ! haveOffset || std::abs (sample - offset) > resnapThreshold)
            {
                offset = sample;           // démarrage, saut (boucle, déplacement du curseur)
                haveOffset = true;
                nSamples = 1;
            }
            else
            {
                // moyenne cumulée au début (convergence rapide), puis lissage lent
                ++nSamples;
                offset += std::max (alpha, 1.0 / (double) nSamples) * (sample - offset);
            }
        }
        else
        {
            haveOffset = false;
        }

        wasPlaying = s.playing;
    }

    TimeEstimate estimate (double wallNow, const SyncParams& p) const noexcept
    {
        TimeEstimate e;
        if (! haveSnap)
            return e;

        e.valid = true;
        e.playing = snap.playing;
        e.hostTime = snap.hostTime;
        e.bpm = snap.bpm;

        double tPred = snap.hostTime;
        if (snap.playing && haveOffset)
        {
            tPred = wallNow + offset;
            tPred = std::min (std::max (tPred, snap.hostTime - 0.05), snap.hostTime + p.maxExtrapolationSec);
        }

        const double tCal = tPred - (snap.playing ? p.latencySec : 0.0);
        e.videoTime = tCal + p.fineSec;
        e.ppqAtVideo = snap.ppq + (tCal - snap.hostTime) * snap.bpm / 60.0;
        return e;
    }

private:
    static constexpr double alpha = 0.02;
    static constexpr double resnapThreshold = 0.15;

    HostSnapshot snap;
    uint64_t lastSerial = 0;
    bool haveSnapSerial = false;
    bool haveSnap = false;
    bool haveOffset = false;
    bool wasPlaying = false;
    double offset = 0.0;
    int nSamples = 0;
};

//==============================================================================
// Analyse de la sortie de "ffmpeg -i fichier" (durée, cadence, taille).
struct ProbeResult
{
    bool ok = false;
    double duration = 0.0;
    double fps = 0.0;
    int width = 0, height = 0;
};

inline ProbeResult parseProbeOutput (const std::string& text)
{
    ProbeResult r;
    std::smatch m;

    static const std::regex durRe (R"(Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?))");
    if (std::regex_search (text, m, durRe))
        r.duration = std::stod (m[1]) * 3600.0 + std::stod (m[2]) * 60.0 + std::stod (m[3]);

    std::istringstream in (text);
    std::string line;
    while (std::getline (in, line))
    {
        const auto p = line.find (" Video:");
        if (p == std::string::npos)
            continue;

        const std::string rest = line.substr (p + 7);

        static const std::regex dimRe (R"([ ,]([1-9]\d{2,4})x([1-9]\d{2,4})[ ,\[])");
        if (std::regex_search (rest, m, dimRe))
        {
            r.width = std::stoi (m[1]);
            r.height = std::stoi (m[2]);
        }

        static const std::regex fpsRe (R"(([\d.]+)\s*fps)");
        static const std::regex tbrRe (R"(([\d.]+)\s*tbr)");
        if (std::regex_search (rest, m, fpsRe))        r.fps = std::stod (m[1]);
        else if (std::regex_search (rest, m, tbrRe))   r.fps = std::stod (m[1]);
        break;
    }

    r.ok = r.fps > 0.5 && r.duration > 0.0;
    return r;
}

} // namespace vsync
