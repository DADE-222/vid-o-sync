#include "PluginEditor.h"
#include <cmath>

#define U8(s) juce::String::fromUTF8 (s)

//==============================================================================
void VideoView::reset()
{
    frameIndex = -2;
    current = {};
    repaint();
}

void VideoView::setTime (bool timeValid, double seconds, bool calibration)
{
    const bool newFlash = calibration && timeValid && seconds >= 0.0 && std::fmod (seconds, 1.0) < 0.08;

    int idx = -1;
    if (timeValid && seconds >= 0.0 && engine.getState() == VideoEngine::State::Ready && engine.getFrameCount() > 0)
    {
        idx = (int) std::floor (seconds * engine.getFps() + 1.0e-6);
        idx = juce::jmin (idx, engine.getFrameCount() - 1);
    }

    const bool changed = idx != frameIndex || newFlash != flash || timeValid != valid || calibration != calib;

    frameIndex = idx;
    flash = newFlash;
    valid = timeValid;
    calib = calibration;
    timeSec = seconds;

    if (changed)
    {
        current = idx >= 0 ? engine.getFrame (idx) : juce::Image();
        repaint();
    }
}

void VideoView::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);

    if (current.isValid())
    {
        g.setImageResamplingQuality (juce::Graphics::mediumResamplingQuality);
        g.drawImage (current, getLocalBounds().toFloat(), juce::RectanglePlacement::centred);
    }
    else if (hint.isNotEmpty())
    {
        g.setColour (juce::Colours::grey);
        g.setFont (16.0f);
        g.drawFittedText (hint, getLocalBounds().reduced (20), juce::Justification::centred, 4);
    }

    if (flash)
    {
        g.setColour (juce::Colours::white);
        g.fillAll();
    }

    if (valid && timeSec >= 0.0 && engine.getState() == VideoEngine::State::Ready)
    {
        const int total = (int) std::floor (timeSec);
        const int fps = juce::jmax (1, (int) std::lround (engine.getFps()));
        const int ff = juce::jmax (0, frameIndex) % fps;
        const auto text = juce::String::formatted ("%02d:%02d:%02d:%02d   #%d",
                                                   total / 3600, (total / 60) % 60, total % 60, ff,
                                                   juce::jmax (0, frameIndex));

        auto box = getLocalBounds().removeFromBottom (24).removeFromLeft (230).reduced (2);
        g.setColour (juce::Colours::black.withAlpha (0.6f));
        g.fillRoundedRectangle (box.toFloat(), 4.0f);
        g.setColour (flash ? juce::Colours::black : juce::Colours::white);
        g.setFont (juce::Font (14.0f));
        g.drawText (text, box.reduced (6, 0), juce::Justification::centredLeft);
    }
}

//==============================================================================
VideoSyncEditor::VideoSyncEditor (VideoSyncProcessor& p)
    : AudioProcessorEditor (&p), proc (p), view (p.engine)
{
    setResizable (true, true);
    setResizeLimits (560, 380, 2400, 1600);
    setSize (860, 560);

    addAndMakeVisible (view);
    view.setHint (U8 ("Glissez une vidéo ici (mp4, mov, avi, mkv...)\nou cliquez sur « Charger une vidéo »"));

    loadButton.setButtonText (U8 ("Charger une vidéo..."));
    loadButton.onClick = [this] { chooseVideo(); };
    addAndMakeVisible (loadButton);

    statusLabel.setJustificationType (juce::Justification::centredLeft);
    statusLabel.setMinimumHorizontalScale (0.6f);
    addAndMakeVisible (statusLabel);
    addChildComponent (progressBar);

    modeLabel.setText (U8 ("Synchronisation"), juce::dontSendNotification);
    addAndMakeVisible (modeLabel);
    modeBox.addItem (U8 ("Parfaite : image exacte, 60 Hz (recommandé)"), 1);
    modeBox.addItem (U8 ("Équilibrée : 30 Hz"), 2);
    modeBox.addItem (U8 ("Économe : 15 Hz (PC lent)"), 3);
    modeBox.setSelectedId (proc.syncMode.load() + 1, juce::dontSendNotification);
    modeBox.onChange = [this] { proc.syncMode.store (modeBox.getSelectedId() - 1); applyMode(); };
    addAndMakeVisible (modeBox);

    offsetLabel.setText (U8 ("Décalage image"), juce::dontSendNotification);
    addAndMakeVisible (offsetLabel);
    offsetSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    offsetSlider.setRange (-2000.0, 2000.0, 1.0);
    offsetSlider.setTextValueSuffix (" ms");
    offsetSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 90, 22);
    offsetSlider.setDoubleClickReturnValue (true, 0.0);
    offsetSlider.setValue (proc.offsetMs.load(), juce::dontSendNotification);
    offsetSlider.onValueChange = [this] { proc.offsetMs.store ((float) offsetSlider.getValue()); };
    offsetSlider.setTooltip (U8 ("Positif : l'image arrive plus tôt. Négatif : plus tard.\nDouble-clic : remise à zéro."));
    addAndMakeVisible (offsetSlider);

    minusFrame.setButtonText (U8 ("−1 image"));
    plusFrame.setButtonText (U8 ("+1 image"));
    zeroButton.setButtonText ("0");
    minusFrame.onClick = [this] { nudge (-1); };
    plusFrame.onClick  = [this] { nudge (+1); };
    zeroButton.onClick = [this] { offsetSlider.setValue (0.0); };
    addAndMakeVisible (minusFrame);
    addAndMakeVisible (plusFrame);
    addAndMakeVisible (zeroButton);

    calibrationToggle.setButtonText (U8 ("Mode calibration : flash blanc à chaque seconde de la timeline "
                                         "(placez un clap sur une seconde pile et réglez le décalage jusqu'à ce qu'ils coïncident)"));
    addAndMakeVisible (calibrationToggle);

    proc.engine.addChangeListener (this);
    updateStatus();
    applyMode();
}

VideoSyncEditor::~VideoSyncEditor()
{
    stopTimer();
    proc.engine.removeChangeListener (this);
}

void VideoSyncEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1e1e22));
    g.setColour (juce::Colours::white);
}

void VideoSyncEditor::resized()
{
    auto area = getLocalBounds().reduced (8);

    auto top = area.removeFromTop (30);
    loadButton.setBounds (top.removeFromLeft (190));
    top.removeFromLeft (10);
    statusLabel.setBounds (top);
    progressBar.setBounds (top.removeFromRight (200));
    if (progressBar.isVisible())
        statusLabel.setBounds (top);

    area.removeFromTop (8);

    auto bottom = area.removeFromBottom (96);
    auto row1 = bottom.removeFromTop (28);
    modeLabel.setBounds (row1.removeFromLeft (120));
    modeBox.setBounds (row1.removeFromLeft (360));

    bottom.removeFromTop (4);
    auto row2 = bottom.removeFromTop (28);
    offsetLabel.setBounds (row2.removeFromLeft (120));
    zeroButton.setBounds (row2.removeFromRight (36));
    row2.removeFromRight (4);
    plusFrame.setBounds (row2.removeFromRight (80));
    row2.removeFromRight (4);
    minusFrame.setBounds (row2.removeFromRight (80));
    row2.removeFromRight (6);
    offsetSlider.setBounds (row2);

    bottom.removeFromTop (4);
    calibrationToggle.setBounds (bottom.removeFromTop (28));

    area.removeFromBottom (8);
    view.setBounds (area);
}

bool VideoSyncEditor::isInterestedInFileDrag (const juce::StringArray& files)
{
    return files.size() > 0;
}

void VideoSyncEditor::filesDropped (const juce::StringArray& files, int, int)
{
    if (files.size() > 0)
        proc.loadVideo (juce::File (files[0]));
}

void VideoSyncEditor::chooseVideo()
{
    chooser = std::make_unique<juce::FileChooser> (
        U8 ("Choisir une vidéo"),
        juce::File::getSpecialLocation (juce::File::userMoviesDirectory),
        "*.mp4;*.mov;*.m4v;*.avi;*.wmv;*.mkv;*.webm;*.flv;*.mpg;*.mpeg");

    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                          [this] (const juce::FileChooser& fc)
                          {
                              const auto result = fc.getResult();
                              if (result.existsAsFile())
                                  proc.loadVideo (result);
                          });
}

void VideoSyncEditor::nudge (int frames)
{
    const double fps = proc.engine.getFps() > 0.0 ? proc.engine.getFps() : 25.0;
    offsetSlider.setValue (offsetSlider.getValue() + frames * 1000.0 / fps);
}

void VideoSyncEditor::changeListenerCallback (juce::ChangeBroadcaster*)
{
    view.reset();
    updateStatus();
}

void VideoSyncEditor::updateStatus()
{
    auto& e = proc.engine;
    const bool converting = e.getState() == VideoEngine::State::Converting;

    progressBar.setVisible (converting);

    switch (e.getState())
    {
        case VideoEngine::State::Idle:
            statusLabel.setText (U8 ("Aucune vidéo chargée"), juce::dontSendNotification);
            break;
        case VideoEngine::State::Converting:
            statusLabel.setText (U8 ("Préparation de « ") + e.getVideoName()
                                 + U8 (" » (une seule fois, puis c'est instantané)..."), juce::dontSendNotification);
            view.setHint (U8 ("Préparation de la vidéo pour une synchronisation image par image..."));
            break;
        case VideoEngine::State::Ready:
            statusLabel.setText (e.getVideoName() + juce::String::formatted ("   -   %.3f images/s, %d images",
                                                                              e.getFps(), e.getFrameCount()),
                                 juce::dontSendNotification);
            break;
        case VideoEngine::State::Failed:
            statusLabel.setText (e.getMessage(), juce::dontSendNotification);
            view.setHint (e.getMessage());
            break;
    }

    resized();
}

void VideoSyncEditor::applyMode()
{
    int hz = 60;
    if (proc.syncMode.load() == VideoSyncProcessor::Balanced) hz = 30;
    if (proc.syncMode.load() == VideoSyncProcessor::Light)    hz = 15;
    startTimerHz (hz);
}

// Cœur du plugin : l'image affichée est calculée à partir de la position de la timeline
// (pas de lecteur vidéo qui avance seul, donc aucune dérive possible).
void VideoSyncEditor::timerCallback()
{
    if (proc.engine.getState() == VideoEngine::State::Converting)
        progressValue = proc.engine.getProgress() < 0.0 ? -1.0 : proc.engine.getProgress();

    const bool valid = proc.hostTimeValid.load();
    double t = proc.hostTimeSeconds.load();

    if (valid && proc.hostPlaying.load())
    {
        // Entre deux blocs audio, on prolonge le temps avec l'horloge système
        // (limité à 100 ms pour ne jamais s'écarter de la timeline).
        const double dt = (juce::Time::getMillisecondCounterHiRes() - proc.hostStampMs.load()) / 1000.0;
        if (dt > 0.0 && dt < 0.25)
            t += juce::jmin (dt, 0.1);
    }

    t += (double) proc.offsetMs.load() / 1000.0;
    view.setTime (valid, t, calibrationToggle.getToggleState());
}
