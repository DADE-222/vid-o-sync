; Installateur VideoSync (NSIS) - tout-en-un : plugin VST3 + ffmpeg
Unicode true
!include "MUI2.nsh"

!define APPNAME "VideoSync"
!define APPVERSION "1.1.0"
!define VST3DIR "$COMMONFILES64\VST3\VideoSync.vst3"

Name "${APPNAME} ${APPVERSION}"
OutFile "VideoSync-Setup.exe"
RequestExecutionLevel admin
InstallDir "${VST3DIR}"
SetCompressor /SOLID lzma

!define MUI_FINISHPAGE_TEXT "VideoSync est installé.$\r$\n$\r$\nDans FL Studio : Options > Manage plugins > Find installed plugins, puis chargez VideoSync sur une piste du mixeur."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "French"

Section "Install"
  SetRegView 64
  SetOutPath "${VST3DIR}\Contents\x86_64-win"
  File "stage\VideoSync.vst3"
  File "stage\ffmpeg.exe"
  SetOutPath "${VST3DIR}"
  File "stage\LICENSE-ffmpeg.txt"

  WriteUninstaller "${VST3DIR}\Uninstall-VideoSync.exe"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\VideoSync" "DisplayName" "VideoSync (VST3)"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\VideoSync" "DisplayVersion" "${APPVERSION}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\VideoSync" "UninstallString" '"${VST3DIR}\Uninstall-VideoSync.exe"'
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\VideoSync" "NoModify" 1
SectionEnd

Section "Uninstall"
  SetRegView 64
  RMDir /r "${VST3DIR}"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\VideoSync"
  ; Le cache vidéo (%LOCALAPPDATA%\VideoSync\cache) est supprimé aussi
  RMDir /r "$LOCALAPPDATA\VideoSync"
SectionEnd

