// Test du moteur vidéo : conversion ffmpeg -> proxy -> lecture d'images exactes.
#include "../Source/VideoEngine.h"
#include <juce_gui_basics/juce_gui_basics.h>
#include <cstdio>

int main (int argc, char** argv)
{
    setvbuf (stdout, nullptr, _IONBF, 0);
    juce::ScopedJuceInitialiser_GUI init;
    if (argc < 2) return 10;

    VideoEngine engine;
    engine.load (juce::File (juce::String (argv[1])));

    struct Poller : juce::Timer
    {
        VideoEngine& e; juce::uint32 start = juce::Time::getMillisecondCounter();
        explicit Poller (VideoEngine& en) : e (en) { startTimer (100); }
        void timerCallback() override
        {
            std::printf ("tick state=%d progress=%.2f\n", (int) e.getState(), e.getProgress());
            if (e.getState() != VideoEngine::State::Converting || juce::Time::getMillisecondCounter() - start > 90000)
                juce::MessageManager::getInstance()->stopDispatchLoop();
        }
    } poller (engine);

    juce::MessageManager::getInstance()->runDispatchLoop();

    std::printf ("state=%d fps=%.3f frames=%d msg=%s\n", (int) engine.getState(), engine.getFps(),
                 engine.getFrameCount(), engine.getMessage().toRawUTF8());

    if (engine.getState() != VideoEngine::State::Ready) return 1;

    int bad = 0;
    const auto t0 = juce::Time::getMillisecondCounterHiRes();
    for (int i = 0; i < engine.getFrameCount(); ++i)
        if (! engine.getFrame (i).isValid()) ++bad;
    const auto t1 = juce::Time::getMillisecondCounterHiRes();
    auto img = engine.getFrame (37);
    std::printf ("decoded=%d bad=%d ms/frame=%.2f size=%dx%d\n", engine.getFrameCount(), bad,
                 (t1 - t0) / engine.getFrameCount(), img.getWidth(), img.getHeight());
    return bad == 0 ? 0 : 2;
}
