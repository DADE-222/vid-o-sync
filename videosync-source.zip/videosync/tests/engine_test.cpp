// Test d'intégration du moteur vidéo avec un vrai ffmpeg.
// Génère une vidéo H.264 (GOP long + B-frames) dont chaque image a une luminosité unique,
// puis vérifie que l'image demandée pour l'instant t est bien la bonne.
#include <juce_core/juce_core.h>
#include <juce_graphics/juce_graphics.h>
#include <cstdio>
#include <thread>
#include "../Source/VideoEngine.h"

using namespace vsync;

static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++failures; std::printf("ECHEC  ligne %d : %s  ", __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

static double meanLuma (const juce::Image& img)
{
    double sum = 0; int n = 0;
    for (int y = img.getHeight() / 4; y < img.getHeight() * 3 / 4; y += 7)
        for (int x = img.getWidth() / 4; x < img.getWidth() * 3 / 4; x += 7)
        {
            sum += img.getPixelAt (x, y).getRed();
            ++n;
        }
    return n ? sum / n : -1.0;
}

// luminosité attendue (limited range -> JPEG full range) pour l'image n
static double expectedLuma (int64_t n)
{
    const double lum = 20.0 + (double) ((n * 5) % 200);
    return (lum - 16.0) * 255.0 / 219.0;
}

static bool waitFor (const std::function<bool()>& cond, int timeoutMs)
{
    for (int t = 0; t < timeoutMs; t += 20)
    {
        if (cond()) return true;
        juce::Thread::sleep (20);
    }
    return cond();
}

int main()
{
    const juce::File work ("/tmp/vs_test");
    work.deleteRecursively();
    work.createDirectory();
    const auto video = work.getChildFile ("clip test.mp4");   // espace dans le nom : cas réel

    std::printf ("Generation de la video de test (H.264, GOP long, B-frames, 29.97 i/s, avec son)...\n");
    {
        juce::ChildProcess p;
        const juce::String cmd = "ffmpeg -hide_banner -loglevel error -y "
            "-f lavfi -i \"color=c=black:s=320x240:r=30000/1001:d=4,geq=lum='20+mod(N*5\\,200)':cb=128:cr=128\" "
            "-f lavfi -i \"sine=frequency=440:duration=4\" "
            "-pix_fmt yuv420p -c:v libx264 -g 250 -bf 2 -c:a aac -shortest \"" + video.getFullPathName() + "\"";
        CHECK (p.start (cmd), "ffmpeg introuvable");
        p.readAllProcessOutput();
        p.waitForProcessToFinish (60000);
        CHECK (video.existsAsFile(), "video de test non creee");
    }

    VideoEngine engine;

    std::printf ("Conversion...\n");
    engine.load (video, 1);
    const bool ok = waitFor ([&] { auto s = engine.getState(); return s == EngineState::Ready || s == EngineState::Failed; }, 90000);
    CHECK (ok && engine.getState() == EngineState::Ready, "conversion: etat=%d msg=%s",
           (int) engine.getState(), engine.getMessage().toRawUTF8());

    const auto info = engine.getInfo();
    std::printf ("  info: %d/%d i/s, %lld images, %dx%d, duree %.3f s\n", info.fps.num, info.fps.den,
                 (long long) info.totalFrames, info.width, info.height, info.duration);
    CHECK (info.fps == (Fps { 30000, 1001 }), "fps exact");
    CHECK (info.totalFrames >= 119 && info.totalFrames <= 121, "nombre d'images %lld", (long long) info.totalFrames);
    CHECK (info.width == 320 && info.height == 240, "pas d'agrandissement: %dx%d", info.width, info.height);

    std::printf ("Exactitude image par image (mode Parfait)...\n");
    int bad = 0, checked = 0;
    for (int64_t n = 0; n < info.totalFrames; ++n)
    {
        const auto img = engine.getFrame (n, SyncMode::Perfect);
        if (! img.isValid()) { ++bad; continue; }
        const double got = meanLuma (img);
        ++checked;
        if (std::abs (got - expectedLuma (n)) > 2.6)
        {
            ++bad;
            if (bad < 5) std::printf ("  image %lld : luma %.1f attendue %.1f\n", (long long) n, got, expectedLuma (n));
        }
    }
    std::printf ("  %d images verifiees, %d erreurs\n", checked, bad);
    CHECK (bad == 0, "images incorrectes");

    std::printf ("Temps -> image (comme dans le plugin)...\n");
    const double fps = info.fps.value();
    for (double t : { 0.0, 0.5, 1.0, 2.5, 3.9 })
    {
        const auto n = frameForTime (t, fps, info.totalFrames);
        const auto img = engine.getFrame (n, SyncMode::Perfect);
        const double got = meanLuma (img);
        CHECK (img.isValid() && std::abs (got - expectedLuma (n)) <= 2.6, "t=%.2f -> image %lld", t, (long long) n);
    }

    std::printf ("Mode Fluide (prechargement)...\n");
    engine.setPrefetchHint (60, true, SyncMode::Smooth);
    const bool pre = waitFor ([&] { return engine.getFrame (62, SyncMode::Smooth).isValid(); }, 2000);
    CHECK (pre, "le prechargement n'a pas rempli le cache");

    std::printf ("Rechargement depuis le cache...\n");
    engine.load (video, 1);
    CHECK (engine.getState() == EngineState::Ready, "doit etre immediat (cache)");
    CHECK (engine.getFrame (10, SyncMode::Perfect).isValid(), "image 10 depuis le cache");

    std::printf ("Autre qualite (reconversion)...\n");
    engine.load (video, 0);
    CHECK (waitFor ([&] { return engine.getState() == EngineState::Ready; }, 90000), "qualite legere");

    std::printf ("Extraction audio...\n");
    engine.startAudioExtraction (video);
    CHECK (waitFor ([&] { return ! engine.isAudioBusy(); }, 60000), "extraction trop longue");
    const auto wav = work.getChildFile ("clip test_audio.wav");
    std::printf ("  %s\n", engine.getAudioMessage().toRawUTF8());
    CHECK (wav.existsAsFile() && wav.getSize() > 100000, "wav absent ou vide");

    std::printf ("Fichier inexistant / invalide...\n");
    engine.load (work.getChildFile ("nope.mp4"), 1);
    CHECK (engine.getState() == EngineState::Failed, "fichier absent");
    const auto bogus = work.getChildFile ("bogus.mp4");
    bogus.replaceWithText ("ceci n'est pas une video");
    engine.load (bogus, 1);
    CHECK (waitFor ([&] { return engine.getState() == EngineState::Failed; }, 20000), "fichier invalide");
    std::printf ("  message: %s\n", engine.getMessage().toRawUTF8());

    std::printf ("Vidage du cache...\n");
    engine.clearAllCaches();
    CHECK (! VideoEngine::getCacheRoot().exists(), "cache non supprime");

    if (failures == 0) std::printf ("\nTOUS LES TESTS DU MOTEUR PASSENT\n");
    else std::printf ("\n%d ECHEC(S)\n", failures);
    return failures == 0 ? 0 : 1;
}
