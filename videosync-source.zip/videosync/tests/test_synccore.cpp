// Tests de la logique de synchro (sans JUCE).  g++ -std=c++17 -O2 -pthread test_synccore.cpp
#include "../Source/SyncCore.h"
#include <cstdio>
#include <cstdlib>
#include <random>
#include <thread>
#include <vector>

using namespace vsync;

static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++failures; std::printf("ECHEC  %s:%d  %s  ", __FILE__, __LINE__, #cond); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

static void testFps()
{
    CHECK (canonicalFps (29.97) == (Fps { 30000, 1001 }), "29.97");
    CHECK (canonicalFps (23.976) == (Fps { 24000, 1001 }), "23.976");
    CHECK (canonicalFps (59.94) == (Fps { 60000, 1001 }), "59.94");
    CHECK (canonicalFps (25.0) == (Fps { 25, 1 }), "25");
    CHECK (canonicalFps (24.0) == (Fps { 24, 1 }), "24");
    CHECK (canonicalFps (30.0) == (Fps { 30, 1 }), "30");
    CHECK (canonicalFps (120.0) == (Fps { 60, 1 }), "120 -> 60");
    CHECK (canonicalFps (12.5) == (Fps { 12500, 1000 }), "12.5");
    CHECK (canonicalFps (0.0) == (Fps { 25, 1 }), "invalide");
}

static void testFrameMapping()
{
    CHECK (frameForTime (-0.001, 25, 100) == -1, "avant le debut");
    CHECK (frameForTime (0.0, 25, 100) == 0, "frame 0");
    CHECK (frameForTime (0.039, 25, 100) == 0, "juste avant frame 1");
    CHECK (frameForTime (0.04, 25, 100) == 1, "frame 1 pile");
    CHECK (frameForTime (3.96, 25, 100) == 99, "derniere");
    CHECK (frameForTime (4.0, 25, 100) == 100, "apres la fin");
    const double ntsc = 30000.0 / 1001.0;
    CHECK (frameForTime (1001.0 / 30000.0 * 100.0, ntsc, 1000) == 100, "NTSC frame 100 pile");
    CHECK (frameForTime (3600.0, ntsc, 1000000) == (int64_t) std::floor (3600.0 * ntsc), "1h NTSC");
    CHECK (formatTimecode (3723.52, 25) == "01:02:03:13", "timecode %s", formatTimecode (3723.52, 25).c_str());
    CHECK (formatTimecode (-1, 25) == "00:00:00:00", "timecode negatif");
}

static void testBeatFlash()
{
    CHECK (beatFlash (4.0, 120.0), "debut de temps");
    CHECK (beatFlash (4.05, 120.0), "0.05 noire @120bpm = 25 ms : flash encore allume");
    CHECK (! beatFlash (4.2, 120.0), "0.2 noire @120bpm = 100 ms : flash eteint");
    CHECK (! beatFlash (4.5, 120.0), "milieu du temps");
}

static void testProbe()
{
    const char* banner =
        "Input #0, mov,mp4,m4a,3gp,3g2,mj2, from 'x.mp4':\n"
        "  Metadata:\n    major_brand     : isom\n"
        "  Duration: 00:01:10.04, start: 0.000000, bitrate: 1300 kb/s\n"
        "  Stream #0:0[0x1](und): Video: h264 (High) (avc1 / 0x31637661), yuv420p(progressive), "
        "1920x1080 [SAR 1:1 DAR 16:9], 1298 kb/s, 29.97 fps, 29.97 tbr, 30k tbn (default)\n"
        "  Stream #0:1[0x2](und): Audio: aac (LC) (mp4a / 0x6134706D), 48000 Hz, stereo, fltp, 128 kb/s\n";
    auto r = parseProbeOutput (banner);
    CHECK (r.ok, "ok");
    CHECK (std::abs (r.duration - 70.04) < 1e-6, "duree %f", r.duration);
    CHECK (std::abs (r.fps - 29.97) < 1e-6, "fps %f", r.fps);
    CHECK (r.width == 1920 && r.height == 1080, "taille %dx%d", r.width, r.height);

    auto r2 = parseProbeOutput ("  Duration: 00:00:04.00\n  Stream #0:0: Video: mpeg4, yuv420p, 640x360, 25 tbr, 25 tbn\n");
    CHECK (r2.ok && r2.fps == 25.0 && r2.width == 640, "tbr de secours");

    CHECK (! parseProbeOutput ("garbage").ok, "invalide");
    CHECK (! parseProbeOutput ("  Duration: N/A\n  Stream #0:0: Video: h264, 640x360, 25 fps\n").ok, "duree N/A");
}

// Simule un hôte : blocs audio avec gigue et rafales ; compare l'estimation à la vérité terrain.
static void testEstimatorJitter (double blockSec, double jitterSec, bool bursts)
{
    SnapshotChannel ch;
    SyncEstimator est;
    std::mt19937 rng (42);
    std::uniform_real_distribution<double> jit (-jitterSec, jitterSec);

    const double w0 = 1000.0;     // origine de l'horloge locale
    const double hostStart = 12.0;
    SyncParams p;

    double maxBack = 0.0, prev = -1e9;
    double sumErr = 0.0; long nErr = 0;
    std::vector<double> errs;
    double nextBlockTrue = 0.0;
    int k = 0;

    for (double now = 0.0; now < 20.0; now += 0.001)   // l'interface lit à 1 kHz
    {
        while (nextBlockTrue <= now)
        {
            HostSnapshot s;
            const double truePos = hostStart + (double) k * blockSec;
            double cb = nextBlockTrue + jit (rng);
            if (bursts && (k % 4) >= 2) cb -= blockSec;     // rafales : appels groupés
            s.hostTime = truePos;
            s.wall = w0 + std::max (cb, now - 5.0 * blockSec);
            s.playing = true;
            s.valid = true;
            s.ppq = truePos * 2.0;
            s.bpm = 120.0;
            ch.publish (s);
            ++k;
            nextBlockTrue = (double) k * blockSec;
        }

        HostSnapshot snap;
        if (ch.read (snap))
            est.feed (snap);

        const auto e = est.estimate (w0 + now, p);
        if (! e.valid || now < 2.0)       // laisse converger 2 s
        {
            prev = e.videoTime;
            continue;
        }

        const double truth = hostStart + now;
        errs.push_back (e.videoTime - truth);
        sumErr += e.videoTime - truth; ++nErr;
        maxBack = std::max (maxBack, prev - e.videoTime);
        prev = e.videoTime;
    }

    // Biais constant (dû au profil de rafales de l'hôte) : se corrige avec le réglage de latence / calibration.
    // Ce qui compte pour la fluidité et la précision : la variation autour de ce biais.
    const double bias = sumErr / (double) nErr;
    double maxDev = 0.0;
    for (double x : errs) maxDev = std::max (maxDev, std::abs (x - bias));

    std::printf ("  bloc %.1f ms, gigue +-%.1f ms, rafales=%d : biais %.2f ms, variation max %.2f ms, recul max %.3f ms\n",
                 blockSec * 1000, jitterSec * 1000, bursts, bias * 1000, maxDev * 1000, maxBack * 1000);
    CHECK (maxDev < 0.008, "variation trop grande: %f", maxDev);   // bien moins d'une image (40 ms a 25 i/s)
    CHECK (maxBack < 0.004, "recul visible: %f", maxBack);
}

static void testEstimatorEvents()
{
    SnapshotChannel ch;
    SyncEstimator est;
    SyncParams p;
    p.latencySec = 0.080;
    p.fineSec = 0.010;

    auto pub = [&] (double host, double wall, bool playing) {
        HostSnapshot s; s.hostTime = host; s.wall = wall; s.playing = playing; s.valid = true; s.bpm = 120; s.ppq = host * 2;
        ch.publish (s);
        HostSnapshot r; ch.read (r); est.feed (r);
    };

    // Arrêt : position exacte, sans compensation de latence
    pub (5.0, 100.0, false);
    auto e = est.estimate (100.5, p);
    CHECK (e.valid && ! e.playing, "arret");
    CHECK (std::abs (e.videoTime - 5.010) < 1e-9, "arret : exact + decalage fin (%f)", e.videoTime);

    // Lecture : latence appliquée
    for (int i = 0; i < 50; ++i) pub (5.0 + i * 0.01, 100.0 + i * 0.01, true);
    e = est.estimate (100.49, p);
    CHECK (e.playing, "lecture");
    CHECK (std::abs (e.videoTime - (5.49 - 0.080 + 0.010)) < 0.003, "lecture + latence (%f)", e.videoTime);

    // Boucle : saut arrière de 4 s -> recalage immédiat
    pub (1.0, 100.50, true);
    e = est.estimate (100.50, p);
    CHECK (std::abs (e.videoTime - (1.0 - 0.080 + 0.010)) < 0.003, "boucle (%f)", e.videoTime);

    // L'hôte se fige alors qu'il dit "playing" : on n'extrapole pas au-delà de 250 ms
    e = est.estimate (110.0, p);
    CHECK (e.videoTime <= 1.0 + 0.25 - 0.080 + 0.010 + 1e-9, "extrapolation bornee (%f)", e.videoTime);

    // Position invalide
    HostSnapshot bad; bad.valid = false; ch.publish (bad);
    HostSnapshot r; ch.read (r); est.feed (r);
    CHECK (! est.estimate (111.0, p).valid, "invalide");

    // Calibration : le ppq suit l'image affichée (latence incluse)
    SyncEstimator est2;
    HostSnapshot s; s.hostTime = 10.0; s.wall = 50.0; s.playing = true; s.valid = true; s.bpm = 120; s.ppq = 20.0; s.serial = 1;
    est2.feed (s);
    SyncParams q; q.latencySec = 0.1;
    auto e2 = est2.estimate (50.0, q);
    CHECK (std::abs (e2.ppqAtVideo - (20.0 - 0.1 * 2.0)) < 1e-9, "ppq calibration (%f)", e2.ppqAtVideo);
}

static void testSeqlockStress()
{
    SnapshotChannel ch;
    std::atomic<bool> stop { false };
    std::thread writer ([&] {
        double v = 0;
        while (! stop.load())
        {
            HostSnapshot s;
            s.hostTime = s.wall = s.ppq = s.bpm = v;   // champs toujours identiques si lecture cohérente
            s.valid = true; s.playing = ((long long) v % 2) == 0;
            ch.publish (s);
            v += 1.0;
        }
    });

    long long reads = 0, torn = 0;
    const auto t0 = wallNowSeconds();
    while (wallNowSeconds() - t0 < 1.0)
    {
        HostSnapshot r;
        if (ch.read (r))
        {
            ++reads;
            if (! (r.hostTime == r.wall && r.wall == r.ppq && r.ppq == r.bpm
                   && r.playing == (((long long) r.hostTime % 2) == 0)))
                ++torn;
        }
    }
    stop = true;
    writer.join();
    std::printf ("  seqlock : %lld lectures, %lld incoherentes\n", reads, torn);
    CHECK (reads > 1000, "peu de lectures");
    CHECK (torn == 0, "lectures incoherentes");
}

int main()
{
    std::printf ("Fps / images / timecode...\n");
    testFps(); testFrameMapping(); testBeatFlash(); testProbe();
    std::printf ("Estimateur de synchro...\n");
    testEstimatorJitter (512.0 / 48000.0, 0.002, false);
    testEstimatorJitter (1024.0 / 44100.0, 0.004, false);
    testEstimatorJitter (2048.0 / 44100.0, 0.005, true);
    testEstimatorEvents();
    std::printf ("Canal sans verrou...\n");
    testSeqlockStress();

    if (failures == 0) std::printf ("\nTOUS LES TESTS PASSENT\n");
    else std::printf ("\n%d ECHEC(S)\n", failures);
    return failures == 0 ? 0 : 1;
}
